'use strict';

var sqlite3 = require('sqlite3').verbose();
var db;

exports.initDb = function () {
    db = new sqlite3.Database(':memory:');
    db.run('CREATE TABLE bestellungen(rohDaten text)', function (err) {
        if(err)console.error(err);
    });
}

var addOrderRow = function(data){
    db.run(`INSERT INTO bestellungen(rohDaten)
                VALUES (?)`, [data], function (err) {
        if (err) {
            console.error(err);
            return err.message;
        }
        var orderId = this.lastID
        console.log(`A row has been inserted with rowid ${orderId}`);
    });
}

/**
 * Bestelle eine Pizza
 *
 * body Bestellung Erstellt eine neue Pizzabestellung
 * returns Bestellung
 **/
exports.addOrder = function (body) {

    addOrderRow(body);

    return new Promise(function (resolve, reject) {
        resolve(`{"msg": "Danke für die Bestellung bro"}`);
    });
}

