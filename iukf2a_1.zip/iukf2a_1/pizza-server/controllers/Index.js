'use strict';

var fs = require('fs');
var utils = require('../utils/writer.js');
var Index = require('../service/IndexService');

module.exports.rootGET = function rootGET (req, response, next) {

    fs.readFile('./index.html', null, function (error, data) {
        if (error) {
            response.writeHead(404);
            respone.write('Whoops! File not found!');
        } else {
            response.writeHead(200, {
                    'Content-Type': 'text/html'
            });
            response.write(data);
        }
        response.end();
    });
};