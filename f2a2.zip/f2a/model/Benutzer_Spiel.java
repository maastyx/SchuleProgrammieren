package de.bbs.f2a.model;

public class Benutzer_Spiel
{
  int benutzid;
  int spielid;

  public int getBenutzid()
  {
    return benutzid;
  }

  public void setBenutzid( final int benutzid )
  {
    this.benutzid = benutzid;
  }

  public int getSpielid()
  {
    return spielid;
  }

  public void setSpielid( final int spielid )
  {
    this.spielid = spielid;
  }
}
